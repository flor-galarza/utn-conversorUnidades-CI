import{l as o,a as r}from"../chunks/BS_q_DCq.js";export{o as load_css,r as start};
